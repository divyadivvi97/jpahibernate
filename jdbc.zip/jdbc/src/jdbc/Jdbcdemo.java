package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbcdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
Connection conn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","root");
		
		/* Statement stmt =conn.createStatement();
		String insertQuery="insert into EMPLOYEE values(101,'king'8900)";
	int n=	stmt.executeUpdate(insertQuery);*/
String insert="insert into EMPLOYEE values(?,?,?)";

String selectQuery ="select from emplyee where emp id=? ";
PreparedStatement pstmt= conn.prepareStatement(selectQuery);
//pstmt.setInt(1,101);
pstmt.setDouble(1,10100);

ResultSet rs =pstmt.executeQuery();
while(rs.next())
{
	int eid =rs.getInt(1);
	double sal=rs.getDouble("salary");
}


/*pstmt.setInt(1,101);
pstmt.setString(2,"king");
pstmt.setDouble(3,4000);
*/




int n= pstmt.executeUpdate();
		 if(n>0)
		 {
			 System.out.println(n+"record inserted...");
		 }
		 
		 conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
