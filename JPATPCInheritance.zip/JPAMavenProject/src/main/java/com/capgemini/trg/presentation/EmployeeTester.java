package com.capgemini.trg.presentation;

import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
								new EmployeeServiceImpl();
	
	public static void main(String[] args) {
		Employee employee=
			    new Employee(null,"Jacky",new GregorianCalendar(2016,10,15),"Manager",65000.0,10);
			
			addNewEmployee(employee);
		
//		try {
//			Employee e1= employeeService.getEmployeeDetails(1);
//			System.out.println(e1.getHiredate());
//			System.out.println(e1);
//		} catch (EmployeeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
////		}
//		try{
//		List<Employee> employeeList=employeeService.getAllEmployees();
//		showEmployees(employeeList);
//		}catch(EmployeeException e){
//			e.printStackTrace();
//	}
//		}
//		
//		try {
//			Employee employee=employeeService.getEmployeeDetails(1);
//			System.out.println(employee);
//			Double salary=employee.getSalary();
//			salary=salary+10000;
//			employee.setSalary(salary);
//			//employee.setSalary(68000.0);
//			employeeService.updateEmployee(employee);
//			employee=employeeService.getEmployeeDetails(1);
//			System.out.println(employee);
//			
//			
//		} catch (EmployeeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
		
//		try {
//			employeeService.deleteEmployee(4);
//			//System.out.println(e1.getHiredate());
//			//System.out.println(e1);
//		} catch (EmployeeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
		
		private static void showEmployees(List<Employee> employeeList){
		Iterator<Employee> iterator=employeeList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
		
		
		
		
		
//		try {
//			
//			employeeService.updateEmployee();
//			//System.out.println(e1.getHiredate());
//			//System.out.println(e1);
//		} catch (EmployeeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		//addNewEmployee(employee);
		
		//deleteEmployee(18);
		 //updateEmployee(employee);
		// getEmployeeDetails(5);
		// getallEmployees();
	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}
	private static void deleteEmployee(Integer empid) {
		try {
			employeeService.deleteEmployee(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}
	private static void updateEmployee(Employee employee) {
		try {
			employeeService.updateEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}
	
	private static void getEmployeeDetails(Integer empid) {
		try {
			employeeService.getEmployeeDetails(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}

	}

	
	private static void getallEmployees(){
		try {
			employeeService.getAllEmployees();
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}
	
	
	
}
