package com.capgemini.trg.presentation;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class JPQLDemo {

	public static void main(String[] args){
		EntityManager entityManager=JPAUtil.getEntityManager();
//		String jql1="select e from Employee e";
//				TypedQuery<Employee> typedQuery1=entityManager.createQuery(jql1,Employee.class);
//				List<Employee> employeeList=typedQuery1.getResultList();
//				showEmployees(employeeList);
				
				/*String jql2="select e from Employee e where e.job=:pjob AND e.salary>:psalary";
				TypedQuery<Employee> typedQuery2=entityManager.createQuery(jql2,Employee.class);
				//TypedQuery<Employee> typedQuery2=entityManager.createQuery(jql2,Employee.class).setParameter("pjob","Manager");// direct statement
				typedQuery2.setParameter("pjob","Manager");
				typedQuery2.setParameter("psalary",50000.00);
				List<Employee> employeeList=typedQuery2.getResultList();
				showEmployees(employeeList);*/
				
		
		String jql2="select e from Employee e where e.job=?1 AND e.deptno=?2";
	   TypedQuery<Employee> typedQuery=entityManager.createQuery(jql2,Employee.class).setParameter(1,"Manager").setParameter(2,10); 
		/*TypedQuery<Employee> typedQuery=entityManager.createQuery(jql2,Employee.class);
		typedQuery.setParameter(1,"Manager");
		typedQuery.setParameter(2,10);*/
		List<Employee> employeeList=typedQuery.getResultList();
		showEmployees(employeeList);
		
		//calling native queries with jpa
		/*Query query=entityManager.createNativeQuery("select * from employee where job=?",Employee.class);
		query.setParameter(1, "Manager");
		List<Employee> employeeList1=query.getResultList();
		showEmployees(employeeList1);*/
		
		
		
		
//		Query query1=entityManager.createNamedQuery("q1");
//		List<Employee> employeeList1=query1.getResultList();
//		showEmployees(employeeList1);
	}

	private static void showEmployees(List<Employee> employeeList) {
		// TODO Auto-generated method stub
		Iterator<Employee> iterator =employeeList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
	}
	
	
	
	
}
